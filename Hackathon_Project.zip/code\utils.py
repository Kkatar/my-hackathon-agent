import os
import pandas as pd
import logging
from typing import List, Dict

# Set up simple logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("TriageAgent")

def load_csv(filepath: str) -> pd.DataFrame:
    if not os.path.exists(filepath):
        logger.error(f"File not found: {filepath}")
        return pd.DataFrame()
    return pd.read_csv(filepath)

def save_csv(df: pd.DataFrame, filepath: str):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    df.to_csv(filepath, index=False)
    logger.info(f"Results saved to {filepath}")

def clean_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    return " ".join(text.split()).lower()

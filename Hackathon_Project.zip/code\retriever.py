import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from utils import clean_text

class DocumentRetriever:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.documents = []
        self.vectorizer = TfidfVectorizer(stop_words='english')
        self.tfidf_matrix = None
        self._load_corpus()

    def _load_corpus(self):
        """Loads all txt/md files from the data directory into memory."""
        if not os.path.exists(self.data_dir):
            return
            
        for root, _, files in os.walk(self.data_dir):
            for file in files:
                if file.endswith('.txt') or file.endswith('.md'):
                    path = os.path.join(root, file)
                    # Extract product area from folder name
                    product_area = os.path.basename(root)
                    try:
                        with open(path, 'r', encoding='utf-8') as f:
                            content = f.read()
                            self.documents.append({
                                'path': path,
                                'product_area': product_area,
                                'content': content,
                                'clean_content': clean_text(content)
                            })
                    except Exception as e:
                        pass
        
        if self.documents:
            corpus = [doc['clean_content'] for doc in self.documents]
            self.tfidf_matrix = self.vectorizer.fit_transform(corpus)

    def retrieve(self, query: str, top_k: int = 3):
        """Retrieves top_k most relevant documents for a given query."""
        if not self.documents or self.tfidf_matrix is None:
            return [], 0.0

        clean_q = clean_text(query)
        query_vec = self.vectorizer.transform([clean_q])
        similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        
        top_indices = similarities.argsort()[-top_k:][::-1]
        
        results = []
        best_score = similarities[top_indices[0]] if len(top_indices) > 0 else 0.0
        
        for idx in top_indices:
            if similarities[idx] > 0.05: # Minimum threshold
                doc = self.documents[idx].copy()
                doc['score'] = similarities[idx]
                results.append(doc)
                
        return results, best_score

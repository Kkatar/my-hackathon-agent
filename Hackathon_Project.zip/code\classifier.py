from utils import clean_text

class TicketClassifier:
    def __init__(self):
        self.keywords = {
            "product_area": {
                "hackerrank": ["hackerrank", "assessment", "test", "interview", "coding", "compiler"],
                "claude": ["claude", "anthropic", "llm", "tokens", "prompt", "model"],
                "visa": ["visa", "payment", "card", "transaction", "checkout", "billing"]
            },
            "request_type": {
                "bug": ["error", "bug", "crashing", "not working", "fails", "broken", "glitch"],
                "feature_request": ["add", "feature", "new", "wish", "could you", "implement", "support for"],
                "product_issue": ["how to", "help", "cannot find", "issue", "question", "guide"],
                "invalid": ["spam", "asdf", "test", "ignore"]
            },
            "high_risk": ["sue", "legal", "lawyer", "stolen", "fraud", "hacked", "security", "breach", "refund", "chargeback", "urgent", "critical"]
        }

    def classify(self, ticket_text: str):
        text = clean_text(ticket_text)
        
        # 1. Classify Product Area
        product_area = "unknown"
        max_pa_score = 0
        for area, kw_list in self.keywords["product_area"].items():
            score = sum(1 for kw in kw_list if kw in text)
            if score > max_pa_score:
                max_pa_score = score
                product_area = area
                
        # 2. Classify Request Type
        request_type = "product_issue" # default
        max_rt_score = 0
        for rt, kw_list in self.keywords["request_type"].items():
            score = sum(1 for kw in kw_list if kw in text)
            if score > max_rt_score:
                max_rt_score = score
                request_type = rt

        # 3. Assess Risk
        is_high_risk = any(kw in text for kw in self.keywords["high_risk"])

        return {
            "product_area": product_area,
            "request_type": request_type,
            "is_high_risk": is_high_risk
        }

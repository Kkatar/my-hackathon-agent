# Support Triage Agent

A deterministic, offline, terminal-based AI support agent for HackerRank Orchestrate.

## Features
- **Offline RAG**: Uses TF-IDF and Cosine Similarity to find relevant context locally. No external APIs used.
- **Rule-based Classification**: Identifies `product_area`, `request_type`, and assesses risk levels for immediate escalation.
- **Deterministic**: Standardized text pre-processing and scoring.
- **Safe**: Escalate financial, security, and low-confidence queries automatically.

## Requirements
Python 3.10+

## Setup & Execution

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the agent:
   ```bash
   python main.py
   ```

3. View results in `../support_tickets/output.csv`.

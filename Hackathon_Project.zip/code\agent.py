from retriever import DocumentRetriever
from classifier import TicketClassifier

class SupportAgent:
    def __init__(self, data_dir: str):
        self.retriever = DocumentRetriever(data_dir)
        self.classifier = TicketClassifier()
        self.confidence_threshold = 0.15 # Minimum similarity score to reply

    def process_ticket(self, ticket_id: str, query: str):
        # 1. Classify
        classification = self.classifier.classify(query)
        
        # 2. Retrieve Context
        docs, confidence = self.retriever.retrieve(query, top_k=2)
        
        # 3. Decision Engine
        if classification["is_high_risk"]:
            return self._escalate(classification, "High-risk keywords detected (e.g., security, legal, financial).")
        
        if confidence < self.confidence_threshold or not docs:
            return self._escalate(classification, f"Low retrieval confidence ({confidence:.2f}). No relevant knowledge base info.")
            
        if classification["request_type"] == "invalid":
            return self._escalate(classification, "Query classified as invalid or spam.")

        # 4. Generate Response (Extractive / Template based for safety)
        best_doc = docs[0]
        
        # Override product area if retrieval strongly suggests another area
        product_area = best_doc['product_area'] if best_doc['product_area'] != "unknown" else classification['product_area']
        
        response_text = f"Based on our documentation, here is the relevant information: {best_doc['content'][:400]}..."
        
        return {
            "status": "replied",
            "product_area": product_area,
            "response": response_text,
            "justification": f"High confidence match ({confidence:.2f}) found in corpus.",
            "request_type": classification["request_type"]
        }

    def _escalate(self, classification: dict, reason: str):
        return {
            "status": "escalated",
            "product_area": classification["product_area"],
            "response": "This ticket has been escalated to a human agent.",
            "justification": reason,
            "request_type": classification["request_type"]
        }
